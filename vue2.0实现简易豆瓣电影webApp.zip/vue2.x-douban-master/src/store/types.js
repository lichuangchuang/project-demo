/**
 * Created by superman on 2016/12/12.
 */

export const FETCH_MOVIES = 'movie/FETCH_MOVIES';
export const FETCH_MOVIE_LIST = 'movie/FETCH_MOVIE_LIST';
export const FETCH_MOVIE_BY_ID = 'movie/FETCH_MOVIE_BY_ID';
export const SET_INFINITE_BUSY = 'movie/SET_INFINITE_BUSY';
export const CLEAN_MOVIES = 'movie/CLEAN_MOVIES';
export const CLEAN_MOVIE_LIST = 'movie/CLEAN_MOVIE_LIST';
export const CLEAN_MOVIE = 'movie/CLEAN_MOVIE';
